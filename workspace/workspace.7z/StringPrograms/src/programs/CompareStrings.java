package programs;

public class CompareStrings {

	public static void main(String[] args) {
		String s1="pranaw";
		String s2="Pranaw";
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.equals(s2));
		System.out.println(s1.equalsIgnoreCase(s2));
	}
}
