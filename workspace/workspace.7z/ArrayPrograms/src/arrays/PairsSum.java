package arrays;

import java.util.Scanner;

public class PairsSum {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int size=sc.nextInt();
		int a[]=new int[size];
		
		System.out.println("Enter sum which you want to find in the array");
		int sum=sc.nextInt();
		
		for(int i=0;i<size;i++)
		{
		//	for(int j=)
		}
		
	}
}
