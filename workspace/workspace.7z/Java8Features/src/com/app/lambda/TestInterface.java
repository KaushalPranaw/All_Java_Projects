package com.app.lambda;

public interface TestInterface {

	public void square(int a);
//	public void square1(int a);
	 
}
