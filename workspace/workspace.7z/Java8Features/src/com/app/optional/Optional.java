package com.app.optional;

public class Optional {

	public static void main(String[] args) {
		
	}
	
}
