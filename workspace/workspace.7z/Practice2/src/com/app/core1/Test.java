package com.app.core1;

public class Test {

	public static void main(String[] args) {
		Student s=new Student(1, "pranaw", "abc", 10, 100.10);
		System.out.println(s.fetchDetails());
	}
}
