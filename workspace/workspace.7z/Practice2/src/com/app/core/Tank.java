package com.app.core;

public class Tank 
{
	private int level;
	public Tank(int l) {
		// TODO Auto-generated constructor stub
		level=l;
	}
	
	public void setLevel(int level1)
	{
		level=level1;
	}
	
	public int getLevel()
	{
		return level;
	}
	 
}
