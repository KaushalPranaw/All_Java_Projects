package com.app;

import java.util.Scanner;

public class abc {

	public static void main(String[] args) {
		String[] s=new String[5];
		Scanner sc=new Scanner(System.in);
		for(String ss:s)
		{
			String sss=sc.nextLine();
			ss=sss;
		}
		for(String ss:s)
		{
			System.out.println(ss);
			System.out.println(ss+1);
		}
	}
}
