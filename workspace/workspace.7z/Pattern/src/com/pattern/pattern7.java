package com.pattern;

public class pattern7 {

	public static void main(String[] args) {
		for(int i=1;i<=4;i++)
		{
			for(int j=1;j<=7;j++)
			{
				if(i%2==j%2)
				{
					System.out.print(" ");
				}
				else if(j>=5-i&&j<=3+i)
				{
					System.out.print(1);
				}
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
}
