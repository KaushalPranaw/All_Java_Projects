import java.util.Scanner;

public class A {
	public static void main(String ar[])
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c;
		c=a+b;
		System.out.println(c);
		
	}
}
