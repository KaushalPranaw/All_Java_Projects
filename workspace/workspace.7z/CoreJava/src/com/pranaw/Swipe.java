package com.pranaw;

import java.util.Scanner;

public class Swipe {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		char c[]=s.toCharArray();
		for(char ch:c)
		{
			System.out.println(ch);
		}
	}
}
