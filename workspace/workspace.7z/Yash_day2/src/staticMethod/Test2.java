package staticMethod;

interface I2
{
	public static void m1()
	{
		System.out.println("interface static method");
	}
}

public class Test2 {

	public static void main(String[] args) {
		I.m1();
		 
		
	}
}
