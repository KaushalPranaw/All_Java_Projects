package staticMethod;

interface Test4
{
	public static void main(String[] args) {
		System.out.println("Interface main method");
	}
}

 