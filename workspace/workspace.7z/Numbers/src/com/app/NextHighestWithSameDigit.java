package com.app;

public class NextHighestWithSameDigit {

	public static void main(String[] args) {
		
	}
}
