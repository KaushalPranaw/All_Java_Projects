package tester;

import java.util.Scanner;

public class SwaapingArray {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter size of the array");
		int a[]={1,2,3,4,5};
		 int i=0;
		while(i!=a.length)
		{
			
		}
		for(i=0;i<a.length;i++)
		{
		//	a[i]=sc.nextInt();
			System.out.println(a[i]);
		}
		
	}
}
