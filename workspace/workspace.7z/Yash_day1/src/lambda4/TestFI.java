package lambda4;

@FunctionalInterface // to get the error in compiler time we use annotation //optional but rec
public interface TestFI {

	int add(int a,int b);
	 
}
 