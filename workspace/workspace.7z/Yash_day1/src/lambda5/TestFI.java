package lambda5;

@FunctionalInterface // to get the error in compiler time we use annotation //optional but rec
public interface TestFI {

	int square(int n);
	 
}
 