package com.app.tester;
class Test
{
	 public static void main(String args[])
	    {
	        String s1 = "geeksquiz";
	        String s2 = "geeksquiz";
	       System.out.println(s1==s2);
    }
}