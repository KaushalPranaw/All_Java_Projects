package com.app.core;

public class VendorImpl extends Vendor implements Vendor.A.C.B.D.E {

	@Override
	public int c() {
		// TODO Auto-generated method stub
		return 5;
	}

	public static void main(String[] args) {
		Vendor.A.C.B.D.E c=new VendorImpl();
		System.out.println(c.c());
		Vendor.A.display();
	}
}
