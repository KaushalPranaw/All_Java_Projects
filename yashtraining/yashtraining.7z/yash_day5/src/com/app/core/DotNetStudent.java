package com.app.core;

public class DotNetStudent extends Student {

	
	
	@Override
	public void display() {
		System.out.println("Dotnet details "+id+" "+name);
	}
 
	
}
