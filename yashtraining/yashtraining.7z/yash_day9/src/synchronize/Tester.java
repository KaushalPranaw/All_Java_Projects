package synchronize;

public class Tester extends Thread {

	public static void main(String[] args) {
		Thread.getAllStackTraces().keySet().forEach(System.out::println);
	}
}
