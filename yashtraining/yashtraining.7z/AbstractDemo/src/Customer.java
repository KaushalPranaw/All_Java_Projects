
public class Customer extends Employee {

	@Override
	public void calSal() {
		// TODO Auto-generated method stub
		
	}

}
