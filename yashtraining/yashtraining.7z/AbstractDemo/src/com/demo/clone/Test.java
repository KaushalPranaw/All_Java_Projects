package com.demo.clone;

public class Test {

	int id;
	String name;
	
	/*public Test() {
		System.out.println("abc");
	}
	 
	public Test(int id, String name)
	{
		System.out.println(id+" "+name);
		System.out.println(this.id+" "+this.name);
	}*/
	
	public static void main(String[] args) {
		
		 
	}
}
