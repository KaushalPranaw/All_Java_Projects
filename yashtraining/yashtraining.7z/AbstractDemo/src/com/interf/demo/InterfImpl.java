package com.interf.demo;

public class InterfImpl extends AbstrcatDemo {

	@Override
	public void a() {
		System.out.println("a()");
		
	}

	@Override
	public void b() {
		System.out.println("b()");
		
	}

	@Override
	public void d() {
		System.out.println("d()");
		
	}

	
}
