package com.interf.demo;

public interface Interf {
	void a();
	void b();
	void c();
	void d();
	
}
