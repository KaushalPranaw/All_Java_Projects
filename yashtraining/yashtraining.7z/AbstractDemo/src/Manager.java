
public class Manager extends Employee {

	@Override
	public void calSal() {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		Employee e=new Manager();
		e.calSal();
	}
}
