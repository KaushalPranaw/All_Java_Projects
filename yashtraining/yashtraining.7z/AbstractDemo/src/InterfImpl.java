
public class InterfImpl implements Interf {

}
