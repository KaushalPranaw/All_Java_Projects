package exec;

import java.io.FileInputStream;
import java.io.IOException;

public class TestExec {

	public static void main(String[] args) {
		try
		{
			System.out.println("hello");
			FileInputStream i=new FileInputStream("");
		}
		catch (IOException e) {
			// TODO: handle exception
		}
	}
}
