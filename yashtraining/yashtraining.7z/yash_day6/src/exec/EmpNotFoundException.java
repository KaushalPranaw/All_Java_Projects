package exec;

@SuppressWarnings("serial")
public class EmpNotFoundException extends Exception {

	public EmpNotFoundException(String msg) {
		super(msg);
	}
}
 
