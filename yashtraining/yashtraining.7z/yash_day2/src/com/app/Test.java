package com.app;

public class Test {

	static int i=10;
	{
		System.out.println(i+1);
	}
	static
	{
		i=10;
		System.out.println(i);
	}
	public static void main(TestStringLiteral[] args) {
		System.out.println(11);
		
	}
}
