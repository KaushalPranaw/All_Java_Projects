package com.app.tester;

public class AssetionDemo {

	public static void main(String[] args) {
		int value=24;
		assert value >=25 : "under weight";
		System.out.println("value is : "+value);
	}
}
