package com.innerclass.nestedinterface;

public class Parent1 {
	 
	interface Child1
	{
		void msg();
	}
}
