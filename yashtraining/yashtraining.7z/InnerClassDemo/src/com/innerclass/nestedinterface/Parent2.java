package com.innerclass.nestedinterface;

public interface Parent2 {
	 
	class Child
	{
		static void msg()
		{
			System.out.println("child msg()");
		}
	}
}
