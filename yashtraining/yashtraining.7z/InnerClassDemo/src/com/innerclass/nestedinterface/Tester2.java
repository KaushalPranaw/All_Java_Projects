package com.innerclass.nestedinterface;

public class Tester2  implements Parent2
{

	public static void main(String[] args) {
		 
		Parent2.Child.msg();
		 
	}
}
