package com.innerclass.nestedinterface;

public interface Parent {
	void show();
	interface Child
	{
		void msg();
	}
}
