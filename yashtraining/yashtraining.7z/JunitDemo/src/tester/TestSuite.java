package tester;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)

@Suite.SuiteClasses({
	TestLogic1.class,TestLogic2.class
})


public class TestSuite {

}
