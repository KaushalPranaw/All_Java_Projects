package com.app.overriding;
public class Animal {
	 
    protected void move() {
        System.out.println("move");
    }
}