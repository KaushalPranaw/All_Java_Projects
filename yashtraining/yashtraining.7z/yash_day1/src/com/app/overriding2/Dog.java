package com.app.overriding2;

import com.app.overriding.Animal;

public class Dog extends Animal {
	 
    public void move() {
        System.out.println("dog");
    }
}