package com.app.list;

import java.util.*;

class hashtable {
	public static void main(String args[]) {
		ArrayList<String> a = new ArrayList<>();
		ArrayList<String> a1 = new ArrayList<>();
		a.add("a");
		a1.add("a");
		System.out.println(a.equals(a1));
	}
}