package mcqs;

public class Test2 {

	static int m=5;
	static void m()
	{
		//this.m;
	}
}
