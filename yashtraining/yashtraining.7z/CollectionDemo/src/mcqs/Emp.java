package mcqs;

public class Emp {

	private String name;

	public Emp(String name) {
		super();
		this.name = name;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 1;
	}
	
}
