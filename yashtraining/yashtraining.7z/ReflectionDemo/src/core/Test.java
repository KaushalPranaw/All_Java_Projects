package core;

public class Test {

	private String s;

	public Test() {
		s = "pranaw";
	}

	public void method1() {
		System.out.println("String is : " + s);

	}

	public void method2(int n) {
		System.out.println("Number is : " + n);

	}

	private void method3() {
		System.out.println("private method invoked");

	}
}
