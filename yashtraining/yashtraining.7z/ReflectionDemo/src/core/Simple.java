package core;

/*public class Simple {
	 Simple();
	public static void main(java.lang.String[]) {
		
	}
}
*/