package com.app.tester;


public class TestExcep {

	public static void main(String[] args) {
		System.out.println((int)(Math.random()*1000000));

	}

}
